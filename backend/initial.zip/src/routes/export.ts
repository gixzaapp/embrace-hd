import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { HttpError } from '../middleware/errorHandler.js';
import {
  exportWhatsAppHd,
  getExportPath,
  getUploadsDir,
  type ExportDelivery,
  type ExportPreset,
} from '../services/exportVideo.js';

export const exportRouter = Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: async (_req, _file, cb) => {
      try {
        const dir = await getUploadsDir();
        cb(null, dir);
      } catch (err) {
        cb(err as Error, '');
      }
    },
    filename: (_req, file, cb) => {
      const safe = file.originalname.replace(/[^\w.\-]+/g, '_').slice(0, 80);
      cb(null, `${Date.now()}_${safe || 'input.mp4'}`);
    },
  }),
  limits: {
    fileSize: 250 * 1024 * 1024,
  },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith('video/') && !file.originalname.match(/\.(mp4|mov|m4v|webm)$/i)) {
      cb(new Error('Only video uploads are allowed'));
      return;
    }
    cb(null, true);
  },
});

const fieldsSchema = z.object({
  preset: z.enum(['720p', '1080p']).default('720p'),
  statusLengthSec: z.coerce.number().refine((n) => n === 30 || n === 60),
  delivery: z.enum(['status', 'chat-hd']).default('status'),
});

/**
 * POST /v1/export
 * multipart: video (file) + preset + statusLengthSec + delivery
 * Returns JSON with a download URL (avoids shipping a huge MP4 through the
 * Capacitor WebView bridge as base64).
 */
exportRouter.post('/', (req, res, next) => {
  upload.single('video')(req, res, (err) => {
    if (err) {
      next(new HttpError(400, err.message || 'Upload failed'));
      return;
    }
    void (async () => {
      const file = req.file;
      if (!file) {
        throw new HttpError(400, 'video file is required (field name: video)');
      }

      const parsed = fieldsSchema.safeParse(req.body);
      if (!parsed.success) {
        fs.unlink(file.path, () => undefined);
        throw new HttpError(400, 'Invalid export options', parsed.error.flatten());
      }

      const { preset, statusLengthSec, delivery } = parsed.data;

      try {
        const result = await exportWhatsAppHd({
          inputPath: file.path,
          preset: preset as ExportPreset,
          statusLengthSec: statusLengthSec as 30 | 60,
          delivery: delivery as ExportDelivery,
        });

        res.json({
          jobId: result.jobId,
          filename: result.filename,
          downloadPath: `/v1/export/${encodeURIComponent(result.filename)}`,
          preset: result.preset,
          statusLengthSec: result.statusLengthSec,
          sizeBytes: result.sizeBytes,
          delivery: result.delivery,
        });
      } finally {
        fs.unlink(file.path, () => undefined);
      }
    })().catch(next);
  });
});

/**
 * GET /v1/export/:filename — re-download a previously exported file
 */
exportRouter.get('/:filename', (req, res, next) => {
  try {
    const filename = path.basename(req.params.filename);
    if (!filename.endsWith('.mp4')) {
      throw new HttpError(400, 'Invalid export filename');
    }
    const full = getExportPath(filename);
    if (!fs.existsSync(full)) {
      throw new HttpError(404, 'Export not found');
    }
    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    fs.createReadStream(full).pipe(res);
  } catch (err) {
    next(err);
  }
});
