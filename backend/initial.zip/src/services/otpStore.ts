import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomInt } from 'node:crypto';
import { env } from '../config/env.js';

export type OtpRecord = {
  phoneE164: string;
  codeHash: string;
  mode: 'login' | 'register';
  name?: string;
  deviceId?: string;
  attempts: number;
  expiresAt: string;
  createdAt: string;
};

type OtpsFile = Record<string, OtpRecord>;

const MAX_ATTEMPTS = 5;

function otpsPath(): string {
  return path.join(env.dataDir, 'otps.json');
}

function hashCode(code: string): string {
  return createHash('sha256').update(code).digest('hex');
}

export function generateOtpCode(): string {
  return String(randomInt(0, 1_000_000)).padStart(6, '0');
}

async function readOtps(): Promise<OtpsFile> {
  try {
    const raw = await fs.readFile(otpsPath(), 'utf8');
    return JSON.parse(raw) as OtpsFile;
  } catch {
    return {};
  }
}

async function writeOtps(data: OtpsFile): Promise<void> {
  await fs.mkdir(env.dataDir, { recursive: true });
  await fs.writeFile(otpsPath(), JSON.stringify(data, null, 2), 'utf8');
}

export async function saveOtp(options: {
  phoneE164: string;
  code: string;
  mode: 'login' | 'register';
  name?: string;
  deviceId?: string;
}): Promise<OtpRecord> {
  const now = new Date();
  const expiresAt = new Date(
    now.getTime() + Math.max(60, env.authOtpTtlSec) * 1000
  ).toISOString();

  const otps = await readOtps();
  const record: OtpRecord = {
    phoneE164: options.phoneE164,
    codeHash: hashCode(options.code),
    mode: options.mode,
    name: options.name,
    deviceId: options.deviceId,
    attempts: 0,
    expiresAt,
    createdAt: now.toISOString(),
  };
  otps[options.phoneE164] = record;
  await writeOtps(otps);
  return record;
}

export type VerifyOtpResult =
  | { ok: true; record: OtpRecord }
  | { ok: false; reason: 'missing' | 'expired' | 'invalid' | 'locked' };

export async function verifyOtp(
  phoneE164: string,
  code: string
): Promise<VerifyOtpResult> {
  const otps = await readOtps();
  const record = otps[phoneE164];

  // Testing bypass: a fixed OTP always verifies (if configured).
  if (env.authTestOtp && code.trim() === env.authTestOtp) {
    if (record) {
      delete otps[phoneE164];
      await writeOtps(otps);
    }
    console.warn(`[Auth OTP] test OTP accepted for ${phoneE164}`);
    return {
      ok: true,
      record:
        record ?? {
          phoneE164,
          codeHash: hashCode(code.trim()),
          mode: 'login',
          attempts: 0,
          expiresAt: new Date(Date.now() + 60_000).toISOString(),
          createdAt: new Date().toISOString(),
        },
    };
  }

  if (!record) return { ok: false, reason: 'missing' };

  if (new Date(record.expiresAt).getTime() < Date.now()) {
    delete otps[phoneE164];
    await writeOtps(otps);
    return { ok: false, reason: 'expired' };
  }

  if (record.attempts >= MAX_ATTEMPTS) {
    return { ok: false, reason: 'locked' };
  }

  if (record.codeHash !== hashCode(code.trim())) {
    record.attempts += 1;
    otps[phoneE164] = record;
    await writeOtps(otps);
    if (record.attempts >= MAX_ATTEMPTS) {
      return { ok: false, reason: 'locked' };
    }
    return { ok: false, reason: 'invalid' };
  }

  delete otps[phoneE164];
  await writeOtps(otps);
  return { ok: true, record };
}
