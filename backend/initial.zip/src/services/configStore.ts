import fs from 'node:fs/promises';
import path from 'node:path';
import { env } from '../config/env.js';
import type { AppConfig } from '../types.js';

const DEFAULT_CONFIG: AppConfig = {
  appId: 'com.embracehd.app',
  trialDurationDays: 7,
  adsEnabled: true,
  premiumEntitlementId: 'premium',
  products: {
    monthly: 'embrace_hd_monthly',
    yearly: 'embrace_hd_yearly',
    lifetime: 'embrace_hd_lifetime',
  },
  featureFlags: {
    lifetimePlan: true,
    imageToVideo: false,
    nativeWatermark: false,
  },
  minAppVersion: '0.1.0',
  updatedAt: new Date().toISOString(),
};

function configPath(): string {
  return path.join(env.dataDir, 'config.json');
}

export async function ensureDataDir(): Promise<void> {
  await fs.mkdir(env.dataDir, { recursive: true });
}

export async function getAppConfig(): Promise<AppConfig> {
  await ensureDataDir();
  try {
    const raw = await fs.readFile(configPath(), 'utf8');
    const parsed = JSON.parse(raw) as Partial<AppConfig>;
    return {
      ...DEFAULT_CONFIG,
      ...parsed,
      products: { ...DEFAULT_CONFIG.products, ...parsed.products },
      featureFlags: { ...DEFAULT_CONFIG.featureFlags, ...parsed.featureFlags },
    };
  } catch {
    await fs.writeFile(configPath(), JSON.stringify(DEFAULT_CONFIG, null, 2), 'utf8');
    return { ...DEFAULT_CONFIG };
  }
}

export { DEFAULT_CONFIG };
