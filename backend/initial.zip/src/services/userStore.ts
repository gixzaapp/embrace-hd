import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { env } from '../config/env.js';

export type AuthUser = {
  id: string;
  phoneE164: string;
  name?: string;
  deviceIds: string[];
  createdAt: string;
  updatedAt: string;
};

type UsersFile = Record<string, AuthUser>;

function usersPath(): string {
  return path.join(env.dataDir, 'users.json');
}

async function readUsers(): Promise<UsersFile> {
  try {
    const raw = await fs.readFile(usersPath(), 'utf8');
    return JSON.parse(raw) as UsersFile;
  } catch {
    return {};
  }
}

async function writeUsers(data: UsersFile): Promise<void> {
  await fs.mkdir(env.dataDir, { recursive: true });
  await fs.writeFile(usersPath(), JSON.stringify(data, null, 2), 'utf8');
}

export function normalizePhoneE164(input: string): string | null {
  const digits = input.replace(/[^\d+]/g, '');
  if (!digits) return null;
  const withPlus = digits.startsWith('+') ? digits : `+${digits}`;
  const only = withPlus.replace(/[^\d]/g, '');
  if (only.length < 8 || only.length > 15) return null;
  return `+${only}`;
}

export async function findUserByPhone(phoneE164: string): Promise<AuthUser | null> {
  const users = await readUsers();
  return (
    Object.values(users).find((u) => u.phoneE164 === phoneE164) ?? null
  );
}

export async function getUserById(id: string): Promise<AuthUser | null> {
  const users = await readUsers();
  return users[id] ?? null;
}

export async function upsertUserForAuth(options: {
  phoneE164: string;
  name?: string;
  deviceId?: string;
  mode: 'login' | 'register';
}): Promise<{ user: AuthUser; created: boolean }> {
  const users = await readUsers();
  const existing = Object.values(users).find(
    (u) => u.phoneE164 === options.phoneE164
  );
  const now = new Date().toISOString();

  if (existing) {
    if (options.mode === 'register' && options.name?.trim()) {
      existing.name = options.name.trim();
    }
    if (options.deviceId?.trim()) {
      const id = options.deviceId.trim();
      if (!existing.deviceIds.includes(id)) {
        existing.deviceIds.push(id);
      }
    }
    existing.updatedAt = now;
    users[existing.id] = existing;
    await writeUsers(users);
    return { user: existing, created: false };
  }

  if (options.mode === 'login') {
    // Allow login-request to create a stub; finalized on verify with mode
    // Actually for login, user must exist. Caller handles this.
  }

  const id = randomUUID();
  const user: AuthUser = {
    id,
    phoneE164: options.phoneE164,
    name: options.name?.trim() || undefined,
    deviceIds: options.deviceId?.trim() ? [options.deviceId.trim()] : [],
    createdAt: now,
    updatedAt: now,
  };
  users[id] = user;
  await writeUsers(users);
  return { user, created: true };
}

export async function ensureUser(
  phoneE164: string,
  options?: { name?: string; deviceId?: string }
): Promise<AuthUser> {
  const found = await findUserByPhone(phoneE164);
  if (found) {
    const { user } = await upsertUserForAuth({
      phoneE164,
      name: options?.name,
      deviceId: options?.deviceId,
      mode: 'login',
    });
    return user;
  }
  const { user } = await upsertUserForAuth({
    phoneE164,
    name: options?.name,
    deviceId: options?.deviceId,
    mode: 'register',
  });
  return user;
}

export function publicUser(user: AuthUser) {
  return {
    id: user.id,
    phoneE164: user.phoneE164,
    name: user.name ?? null,
    createdAt: user.createdAt,
  };
}
