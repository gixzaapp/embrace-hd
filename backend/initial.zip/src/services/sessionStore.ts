import fs from 'node:fs/promises';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { env } from '../config/env.js';

export type SessionRecord = {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
};

type SessionsFile = Record<string, SessionRecord>;

function sessionsPath(): string {
  return path.join(env.dataDir, 'sessions.json');
}

async function readSessions(): Promise<SessionsFile> {
  try {
    const raw = await fs.readFile(sessionsPath(), 'utf8');
    return JSON.parse(raw) as SessionsFile;
  } catch {
    return {};
  }
}

async function writeSessions(data: SessionsFile): Promise<void> {
  await fs.mkdir(env.dataDir, { recursive: true });
  await fs.writeFile(sessionsPath(), JSON.stringify(data, null, 2), 'utf8');
}

export function createSessionToken(): string {
  return randomBytes(32).toString('hex');
}

export async function createSession(userId: string): Promise<SessionRecord> {
  const now = new Date();
  const expiresAt = new Date(
    now.getTime() + Math.max(1, env.sessionTtlDays) * 24 * 60 * 60 * 1000
  ).toISOString();
  const token = createSessionToken();
  const record: SessionRecord = {
    token,
    userId,
    createdAt: now.toISOString(),
    expiresAt,
  };
  const sessions = await readSessions();
  sessions[token] = record;
  await writeSessions(sessions);
  return record;
}

export async function getSession(
  token: string
): Promise<SessionRecord | null> {
  const sessions = await readSessions();
  const record = sessions[token];
  if (!record) return null;
  if (new Date(record.expiresAt).getTime() < Date.now()) {
    delete sessions[token];
    await writeSessions(sessions);
    return null;
  }
  return record;
}

export async function revokeSession(token: string): Promise<void> {
  const sessions = await readSessions();
  if (!sessions[token]) return;
  delete sessions[token];
  await writeSessions(sessions);
}
