import cors from 'cors';
import express from 'express';
import { env } from './config/env.js';
import { errorHandler } from './middleware/errorHandler.js';
import { authRouter } from './routes/auth.js';
import { configRouter } from './routes/config.js';
import { entitlementsRouter } from './routes/entitlements.js';
import { exportRouter } from './routes/export.js';
import { subscriptionRouter } from './routes/subscription.js';
import { trialRouter } from './routes/trial.js';
import { whatsappWebhookRouter } from './routes/whatsappWebhook.js';
import { ensureDataDir } from './services/configStore.js';

export async function createApp() {
  await ensureDataDir();

  const app = express();
  app.use(
    cors({
      origin: env.corsOrigins === '*' ? true : env.corsOrigins,
      exposedHeaders: [
        'X-Embrace-Job-Id',
        'X-Embrace-Preset',
        'X-Embrace-Length',
        'X-Embrace-Size',
      ],
    })
  );
  app.use(express.json({ limit: '64kb' }));

  app.get('/health', (_req, res) => {
    res.json({ ok: true, service: 'embrace-hd-backend' });
  });

  app.use('/v1/auth', authRouter);
  app.use('/v1/whatsapp', whatsappWebhookRouter);
  app.use('/v1/config', configRouter);
  app.use('/v1/subscription', subscriptionRouter);
  app.use('/v1/trial', trialRouter);
  app.use('/v1/entitlements', entitlementsRouter);
  app.use('/v1/export', exportRouter);

  app.use(errorHandler);
  return app;
}
