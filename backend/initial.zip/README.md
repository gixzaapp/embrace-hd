# Embrace HD Backend

Node.js (Express + TypeScript) API for **WhatsApp OTP auth**, **subscription verification**, **remote app config**, **server-side trial claims**, and **WhatsApp HD video export (FFmpeg)**.

## Quick start

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

From the repo root:

```bash
npm run backend
```

Server listens on `http://localhost:8787` by default.

## Environment

| Variable | Description |
|----------|-------------|
| `PORT` | Listen port (default `8787`) |
| `REVENUECAT_SECRET_API_KEY` | RevenueCat **secret** key (optional for export) |
| `CORS_ORIGINS` | `*` or comma-separated origins |
| `DATA_DIR` | JSON + upload/export directory (default `./data`) |
| `WHATSAPP_TOKEN` | Meta WhatsApp Cloud API access token (optional) |
| `WHATSAPP_PHONE_NUMBER_ID` | Cloud API phone number ID (optional; pair with token) |
| `WHATSAPP_VERIFY_TOKEN` | String you set in Meta for webhook verification (`hub.verify_token`) |
| `WHATSAPP_OTP_TEMPLATE` | Approved authentication template name for business-initiated OTP (empty → free-form text) |
| `WHATSAPP_OTP_TEMPLATE_LANG` | Template language code (default `en_US`) |
| `WHATSAPP_OTP_TEMPLATE_HAS_BUTTON` | `false` if the template has no copy-code button (default `true`) |
| `AUTH_OTP_TTL_SEC` | OTP lifetime in seconds (default `300`) |
| `SESSION_TTL_DAYS` | Session token lifetime in days (default `30`) |
| `AUTH_ALLOW_OTP_HINT` | When `true` (default), mock OTP responses may include `otpHint` for local testing. Set `false` in production. |
| `AUTH_TEST_OTP` | Fixed OTP that always verifies (e.g. `123456`) — **testing only**, leave empty in production. |

### WhatsApp OTP delivery

- **App flow (direct):** user enters their WhatsApp number → app calls `POST /v1/auth/request-otp` → backend generates a hashed OTP and sends it via the [WhatsApp Cloud API](https://developers.facebook.com/docs/whatsapp/cloud-api). User enters the code → app calls `POST /v1/auth/verify-otp` → backend authorizes (session token) or rejects.
- When **both** `WHATSAPP_TOKEN` and `WHATSAPP_PHONE_NUMBER_ID` are set, OTPs are sent live. Otherwise the backend uses **mock** mode: the OTP is logged server-side and, if `AUTH_ALLOW_OTP_HINT` is enabled, returned as `otpHint` in the `request-otp` response (non-production testing).
- **Business-initiated sends need an approved authentication template.** Set `WHATSAPP_OTP_TEMPLATE` to your approved template name. Without a template, free-form text is attempted but is only delivered inside the 24h customer-care window (after the user has messaged you).
- The optional `POST /v1/whatsapp/webhook` (Enroll me / Login Me) is still available but no longer required for the direct app flow.

## Endpoints

### `GET /health`
`{ "ok": true }`

### Auth (`/v1/auth`)

Phone is the account id (E.164). Both **Login** and **Register** use the direct OTP flow: enter number → backend sends OTP on WhatsApp → verify.

| Method | Path | Body / notes |
|--------|------|----------------|
| `POST` | `/v1/auth/request-otp` | `{ "phone", "mode": "login"\|"register", "name?", "deviceId?" }` — register requires `name`; sends OTP via WhatsApp; may return `otpHint` in mock |
| `POST` | `/v1/auth/verify-otp` | `{ "phone", "code", "deviceId?" }` → `{ token, expiresAt, user }` |
| `GET` | `/v1/auth/me` | `Authorization: Bearer <token>` |
| `POST` | `/v1/auth/logout` | `Authorization: Bearer <token>` |

OTP: 6 digits, hashed at rest, ~5 min TTL, max 5 attempts.

### WhatsApp webhook (`/v1/whatsapp`) — optional

| Method | Path | Notes |
|--------|------|--------|
| `GET` | `/v1/whatsapp/webhook` | Meta subscribe challenge (`hub.verify_token` must match `WHATSAPP_VERIFY_TOKEN`) |
| `POST` | `/v1/whatsapp/webhook` | `Enroll me` → create user + OTP; `Login Me` → OTP for existing user |

### `GET /v1/config`
Remote app configuration (edit `data/config.json`).

### `POST /v1/subscription/verify`
Body: `{ "appUserId": "<id>" }`

### `POST /v1/trial/claim`
Body: `{ "deviceId": "<stable-id>" }`

### `GET /v1/entitlements?deviceId=&appUserId=`
Merged trial + subscription + entitlement flags.

### `POST /v1/export` (WhatsApp HD)
`multipart/form-data`:
- `video` — input video file
- `preset` — `720p` | `1080p` (chat-hd uses the same reference profile for both)
- `statusLengthSec` — `30` | `60`
- `delivery` — `chat-hd` (default) | `status`

Returns JSON: `jobId`, `filename`, `downloadPath`, `preset`, `statusLengthSec`, `delivery`, `sizeBytes`  
Then `GET /v1/export/:filename` downloads the MP4 (native client uses Filesystem.downloadFile).

Both deliveries use a **Clideo-style WhatsApp Status** encode
([Clideo WhatsApp compressor](https://clideo.com/compress-video-for-whatsapp)):

- **720×1280** or **1080×1920** (9:16) from `preset`
- H.264 High, **CRF 18**, **~2.2 Mbps** maxrate, **30 fps**
- AAC-LC **128k / 44.1 kHz**, `+faststart`
- **Remux (codec copy)** when input already matches WhatsApp specs — no re-encode
- **`status`** (default): ≤15 MB
- **`chat-hd`**: same encode, larger size budget for HD chat → Forward → Status

### `GET /v1/export/:filename`
Re-download a previous export from `data/exports/`.

## Client wiring

```
VITE_BACKEND_ENABLED=true
VITE_API_BASE_URL=http://localhost:8787
```

Android emulator:

```
VITE_BACKEND_ENABLED=true
VITE_API_BASE_URL=http://10.0.2.2:8787
```

When enabled, Convert uses **backend FFmpeg** first. If the API is unreachable, the app falls back to on-device processing.

## Data files

- `data/config.json` — remote defaults
- `data/trials.json` — claimed trials
- `data/users.json` — auth users (phone E.164, optional name, linked deviceIds)
- `data/otps.json` — hashed OTP records
- `data/sessions.json` — opaque session tokens
- `data/uploads/` — temporary uploads (deleted after encode)
- `data/exports/` — completed MP4s
